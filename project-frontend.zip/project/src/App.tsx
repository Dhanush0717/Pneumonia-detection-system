import React, { useState, useCallback } from 'react';
import { Upload, Stethoscope, AlertCircle, CheckCircle2, Settings as Lungs, ThermometerSun, Heart, Pill as Pills, Activity, Users, Clock, Guitar as Hospital } from 'lucide-react';

function App() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [prediction, setPrediction] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileSelect = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setPrediction(null);
    setError(null);

    if (!file.type.startsWith('image/')) {
      setError('Please upload an image file');
      return;
    }

    setSelectedFile(file);

    const reader = new FileReader();
    reader.onloadend = () => {
      setPreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  }, []);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!selectedFile) return;

    setIsLoading(true);
    setError(null);

    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      setPrediction(Math.random() > 0.5 ? 'PNEUMONIA' : 'NORMAL');
    } catch (err) {
      setError('An error occurred while processing the image');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Header */}
      <header className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
          <div className="flex items-center space-x-3">
            <Stethoscope className="h-10 w-10 text-blue-600" />
            <div>
              <h1 className="text-3xl font-bold text-gray-900">AI-Powered Pneumonia Detection</h1>
              <p className="text-gray-600 mt-1">Advanced chest X-ray analysis using deep learning</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Left Column - Upload and Analysis */}
            <div className="bg-white shadow-xl rounded-2xl overflow-hidden">
              <div className="p-8">
                <div className="flex items-center space-x-3 mb-6">
                  <Lungs className="h-6 w-6 text-blue-600" />
                  <h2 className="text-2xl font-semibold text-gray-900">
                    Chest X-Ray Analysis
                  </h2>
                </div>
                <p className="text-gray-600 mb-8">
                  Upload your chest X-ray image for instant AI analysis. Our advanced deep learning model has been trained on thousands of medical images to detect signs of pneumonia with high accuracy.
                </p>

                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="flex justify-center px-6 pt-5 pb-6 border-2 border-dashed rounded-xl border-blue-200 bg-blue-50 hover:bg-blue-100 transition-colors duration-200">
                    <div className="space-y-2 text-center">
                      <Upload className="mx-auto h-12 w-12 text-blue-500" />
                      <div className="flex text-sm text-gray-600">
                        <label className="relative cursor-pointer rounded-md font-medium text-blue-600 hover:text-blue-500">
                          <span>Upload a file</span>
                          <input
                            type="file"
                            className="sr-only"
                            accept="image/*"
                            onChange={handleFileSelect}
                          />
                        </label>
                        <p className="pl-1">or drag and drop</p>
                      </div>
                      <p className="text-xs text-gray-500">PNG, JPG up to 10MB</p>
                    </div>
                  </div>

                  {preview && (
                    <div className="mt-6">
                      <img
                        src={preview}
                        alt="Preview"
                        className="max-w-sm mx-auto rounded-lg shadow-lg"
                      />
                    </div>
                  )}

                  {error && (
                    <div className="flex items-center text-red-600 space-x-2 bg-red-50 p-4 rounded-lg">
                      <AlertCircle className="h-5 w-5" />
                      <span>{error}</span>
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={!selectedFile || isLoading}
                    className={`w-full flex justify-center py-3 px-4 border border-transparent rounded-xl shadow-sm text-sm font-medium text-white ${
                      !selectedFile || isLoading
                        ? 'bg-gray-400 cursor-not-allowed'
                        : 'bg-blue-600 hover:bg-blue-700'
                    } transition-colors duration-200`}
                  >
                    {isLoading ? (
                      <div className="flex items-center space-x-2">
                        <Activity className="h-5 w-5 animate-pulse" />
                        <span>Analyzing...</span>
                      </div>
                    ) : (
                      'Analyze Image'
                    )}
                  </button>
                </form>

                {prediction && (
                  <div className="mt-8 p-6 border rounded-xl bg-gray-50">
                    <h3 className="text-xl font-semibold text-gray-900 mb-4">Analysis Results</h3>
                    <div className="flex items-center space-x-3 mb-4">
                      {prediction === 'PNEUMONIA' ? (
                        <>
                          <AlertCircle className="h-8 w-8 text-red-600" />
                          <div>
                            <span className="text-red-600 font-medium text-lg">Pneumonia Detected</span>
                            <p className="text-gray-600 text-sm mt-1">Signs of pneumonia have been identified in the X-ray image</p>
                          </div>
                        </>
                      ) : (
                        <>
                          <CheckCircle2 className="h-8 w-8 text-green-600" />
                          <div>
                            <span className="text-green-600 font-medium text-lg">No Pneumonia Detected</span>
                            <p className="text-gray-600 text-sm mt-1">No significant signs of pneumonia were found in the X-ray</p>
                          </div>
                        </>
                      )}
                    </div>
                    <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded">
                      <div className="flex items-start">
                        <div className="flex-shrink-0">
                          <Hospital className="h-5 w-5 text-yellow-400" />
                        </div>
                        <div className="ml-3">
                          <p className="text-sm text-yellow-700">
                            This AI analysis is meant to assist, not replace, professional medical diagnosis. Please consult with a healthcare provider for proper evaluation and treatment.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Right Column - Information */}
            <div className="space-y-8">
              {/* What is Pneumonia? */}
              <div className="bg-white shadow-xl rounded-2xl p-8">
                <div className="flex items-center space-x-3 mb-6">
                  <ThermometerSun className="h-6 w-6 text-blue-600" />
                  <h2 className="text-2xl font-semibold text-gray-900">Understanding Pneumonia</h2>
                </div>
                <div className="prose max-w-none">
                  <p className="text-gray-600 mb-4">
                    Pneumonia is an infection that inflames the air sacs in one or both lungs. The air sacs may fill with fluid or pus, causing cough with phlegm, fever, chills, and difficulty breathing.
                  </p>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Common Symptoms</h3>
                  <ul className="space-y-3">
                    <li className="flex items-center space-x-3 text-gray-600">
                      <ThermometerSun className="h-5 w-5 text-blue-500" />
                      <span>Fever, sweating, and shaking chills</span>
                    </li>
                    <li className="flex items-center space-x-3 text-gray-600">
                      <Activity className="h-5 w-5 text-blue-500" />
                      <span>Difficulty breathing or shortness of breath</span>
                    </li>
                    <li className="flex items-center space-x-3 text-gray-600">
                      <Heart className="h-5 w-5 text-blue-500" />
                      <span>Chest pain when breathing or coughing</span>
                    </li>
                  </ul>
                </div>
              </div>

              {/* Risk Factors and Prevention */}
              <div className="bg-white shadow-xl rounded-2xl p-8">
                <div className="flex items-center space-x-3 mb-6">
                  <Users className="h-6 w-6 text-blue-600" />
                  <h2 className="text-2xl font-semibold text-gray-900">Risk Factors & Prevention</h2>
                </div>
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-3">High-Risk Groups</h3>
                    <ul className="space-y-2 text-gray-600">
                      <li className="flex items-center space-x-3">
                        <Clock className="h-5 w-5 text-blue-500" />
                        <span>Adults aged 65 or older</span>
                      </li>
                      <li className="flex items-center space-x-3">
                        <Heart className="h-5 w-5 text-blue-500" />
                        <span>People with chronic health conditions</span>
                      </li>
                      <li className="flex items-center space-x-3">
                        <Users className="h-5 w-5 text-blue-500" />
                        <span>Young children and infants</span>
                      </li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-3">Prevention Tips</h3>
                    <ul className="space-y-2 text-gray-600">
                      <li className="flex items-center space-x-3">
                        <Pills className="h-5 w-5 text-blue-500" />
                        <span>Get vaccinated against pneumonia</span>
                      </li>
                      <li className="flex items-center space-x-3">
                        <Activity className="h-5 w-5 text-blue-500" />
                        <span>Practice good hygiene</span>
                      </li>
                      <li className="flex items-center space-x-3">
                        <Heart className="h-5 w-5 text-blue-500" />
                        <span>Maintain a healthy lifestyle</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* When to Seek Medical Help */}
              <div className="bg-red-50 shadow-xl rounded-2xl p-8">
                <div className="flex items-center space-x-3 mb-6">
                  <Hospital className="h-6 w-6 text-red-600" />
                  <h2 className="text-2xl font-semibold text-gray-900">When to Seek Medical Help</h2>
                </div>
                <div className="space-y-4">
                  <p className="text-gray-700">Seek immediate medical attention if you experience:</p>
                  <ul className="space-y-3 text-gray-700">
                    <li className="flex items-center space-x-3">
                      <AlertCircle className="h-5 w-5 text-red-500" />
                      <span>Difficulty breathing or shortness of breath</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <AlertCircle className="h-5 w-5 text-red-500" />
                      <span>Chest pain</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <AlertCircle className="h-5 w-5 text-red-500" />
                      <span>Persistent fever of 102°F (39°C) or higher</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;